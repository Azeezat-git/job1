name 'custom-cron'

depends 'cron'
